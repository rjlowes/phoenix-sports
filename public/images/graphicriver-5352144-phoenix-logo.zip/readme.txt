Resizable Vector EPS and AI Color customizable 
Fully editable Free font used : Sansation
Main Font used : Optimus Princeps
you can found here : http://www.dafont.com/optimusprinceps.font
